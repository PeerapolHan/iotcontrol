package com.example.iotcontrol;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.Toast;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Map;

import com.github.mikephil.charting.charts.LineChart;
import com.github.mikephil.charting.data.Entry;
import com.github.mikephil.charting.data.LineData;
import com.github.mikephil.charting.data.LineDataSet;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.Calendar;


public class graph extends AppCompatActivity {

    private LineChart mChart;
    ArrayList<Entry> yData;
    DatabaseReference mPostReference;
    SimpleDateFormat sdf = new SimpleDateFormat("ss");
    int s = Integer.parseInt(sdf.format(new Date()));


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_graph);
        getSupportActionBar().setTitle("GRAPH");
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        mChart = (LineChart) findViewById(R.id.line_chart);
        mChart.setDragEnabled(true);
        mChart.setScaleEnabled(false);
        mPostReference = FirebaseDatabase.getInstance().getReference();
        mPostReference.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {

//                status=dataSnapshot.child("Node1/ldr").getValue().toString();
//                ldr.setText(status);

                yData = new ArrayList<>();
                int i =0;
                for (DataSnapshot ds : dataSnapshot.getChildren()){
                    String SV = dataSnapshot.child("Node1/ldr").getValue().toString();
                    Float SensorValue = Float.parseFloat(SV);
                    yData.add(new Entry(s,SensorValue));

                }
                final LineDataSet lineDataSet = new LineDataSet(yData,"LIGHT");
                LineData data = new LineData(lineDataSet);
                mChart.setData(data);
                mChart.notifyDataSetChanged();
                mChart.invalidate();
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });
    }
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu_graph,menu);
        return super.onCreateOptionsMenu(menu);
    }
    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        switch (item.getItemId()){
            case R.id.logutOpt:
                startActivity(new Intent(graph.this, MainActivity.class));
                Toast.makeText(graph.this, "Logout Success", Toast.LENGTH_SHORT).show();
                break;
            case R.id.editnameOpt:
                startActivity(new Intent(graph.this, editAnddelete.class));
                Toast.makeText(graph.this, "editAnddelete", Toast.LENGTH_SHORT).show();
                break;
        }
        return super.onOptionsItemSelected(item);
    }
}