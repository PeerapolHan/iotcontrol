package com.example.iotcontrol;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.Toast;

public class editAnddelete extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_edit_anddelete);
        getSupportActionBar().setTitle("EDIT");
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
    }
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu_edit,menu);
        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        switch (item.getItemId()){
            case R.id.logutOpt:
                startActivity(new Intent(editAnddelete.this, MainActivity.class));
                Toast.makeText(editAnddelete.this, "Logout Success", Toast.LENGTH_SHORT).show();
                break;
            case R.id.graphOpt:
                startActivity(new Intent(editAnddelete.this, graph.class));
                Toast.makeText(editAnddelete.this, "Graph", Toast.LENGTH_SHORT).show();
                break;
        }
        return super.onOptionsItemSelected(item);
    }
}